(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__0f0ba101._.css",
  "static/chunks/node_modules_4d933bd3._.js",
  "static/chunks/src_b942abb6._.js"
],
    source: "dynamic"
});
