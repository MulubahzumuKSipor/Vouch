(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/lib/client.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createClient",
    ()=>createClient
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$ssr$2f$dist$2f$module$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@supabase/ssr/dist/module/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$ssr$2f$dist$2f$module$2f$createBrowserClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@supabase/ssr/dist/module/createBrowserClient.js [app-client] (ecmascript)");
;
function createClient() {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$ssr$2f$dist$2f$module$2f$createBrowserClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createBrowserClient"])(("TURBOPACK compile-time value", "https://uncunljruxfhqpzpmigr.supabase.co"), ("TURBOPACK compile-time value", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVuY3VubGpydXhmaHFwenBtaWdyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njk5NzEzNDEsImV4cCI6MjA4NTU0NzM0MX0.rWTqTlnO_WBUzumrNxTdrXTjig1BvZRqeDegJn_SSow"));
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/cart.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getGuestSessionId",
    ()=>getGuestSessionId
]);
'use client';
function getGuestSessionId() {
    // Prevent SSR crashes
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    let sessionId = localStorage.getItem('vouch_guest_session');
    if (!sessionId) {
        // Generate a secure-enough unique string for the guest cart
        sessionId = 'guest_' + Math.random().toString(36).substring(2, 15) + Date.now().toString(36);
        localStorage.setItem('vouch_guest_session', sessionId);
    }
    return sessionId;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/context/CartContext.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CartProvider",
    ()=>CartProvider,
    "useCart",
    ()=>useCart
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/client.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$cart$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/cart.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
'use client';
;
;
;
;
const CartContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
function CartProvider(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(16);
    if ($[0] !== "b9bb432231fdb4ba4f7a757b3b9be6182013ba3fb23f05f66f416bf106f1d32f") {
        for(let $i = 0; $i < 16; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "b9bb432231fdb4ba4f7a757b3b9be6182013ba3fb23f05f66f416bf106f1d32f";
    }
    const { children } = t0;
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = [];
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    const [items, setItems] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t1);
    const [isOpen, setIsOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const fetchCartData = _CartProviderFetchCartData;
    let t2;
    let t3;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = ({
            "CartProvider[useEffect()]": ()=>{
                let isMounted = true;
                const initializeCart = {
                    "CartProvider[useEffect() > initializeCart]": async ()=>{
                        const data_0 = await fetchCartData();
                        if (isMounted) {
                            if (data_0) {
                                setItems(data_0);
                            }
                            setIsLoading(false);
                        }
                    }
                }["CartProvider[useEffect() > initializeCart]"];
                initializeCart();
                return ()=>{
                    isMounted = false;
                };
            }
        })["CartProvider[useEffect()]"];
        t3 = [];
        $[2] = t2;
        $[3] = t3;
    } else {
        t2 = $[2];
        t3 = $[3];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t2, t3);
    let t4;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = ({
            "CartProvider[refreshCart]": async ()=>{
                setIsLoading(true);
                const data_1 = await fetchCartData();
                if (data_1) {
                    setItems(data_1);
                }
                setIsLoading(false);
            }
        })["CartProvider[refreshCart]"];
        $[4] = t4;
    } else {
        t4 = $[4];
    }
    const refreshCart = t4;
    let t5;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = ({
            "CartProvider[addItem]": async (product)=>{
                setIsOpen(true);
                setItems({
                    "CartProvider[addItem > setItems()]": (prev)=>{
                        const existing = prev.find({
                            "CartProvider[addItem > setItems() > prev.find()]": (item)=>item.product_id === product.id
                        }["CartProvider[addItem > setItems() > prev.find()]"]);
                        if (existing) {
                            return prev.map({
                                "CartProvider[addItem > setItems() > prev.map()]": (item_0)=>item_0.product_id === product.id ? {
                                        ...item_0,
                                        quantity: item_0.quantity + 1
                                    } : item_0
                            }["CartProvider[addItem > setItems() > prev.map()]"]);
                        }
                        return [
                            ...prev,
                            {
                                product_id: product.id,
                                title: product.title,
                                price: product.price_amount,
                                currency: product.price_currency || "USD",
                                cover_image: product.cover_image,
                                quantity: 1,
                                slug: product.slug,
                                username: product.username
                            }
                        ];
                    }
                }["CartProvider[addItem > setItems()]"]);
                const supabase_0 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createClient"])();
                const { data: t6 } = await supabase_0.auth.getUser();
                const { user: user_0 } = t6;
                const sessionId_0 = user_0 ? undefined : (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$cart$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGuestSessionId"])() || undefined;
                const { error } = await supabase_0.rpc("add_to_cart", {
                    p_product_id: product.id,
                    p_session_id: sessionId_0
                });
                if (error) {
                    console.error("Failed to save cart:", error);
                    refreshCart();
                }
            }
        })["CartProvider[addItem]"];
        $[5] = t5;
    } else {
        t5 = $[5];
    }
    const addItem = t5;
    let t6;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = ({
            "CartProvider[removeItem]": async (productId)=>{
                setItems({
                    "CartProvider[removeItem > setItems()]": (prev_0)=>prev_0.filter({
                            "CartProvider[removeItem > setItems() > prev_0.filter()]": (item_1)=>item_1.product_id !== productId
                        }["CartProvider[removeItem > setItems() > prev_0.filter()]"])
                }["CartProvider[removeItem > setItems()]"]);
                const supabase_1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createClient"])();
                const { data: t7 } = await supabase_1.auth.getUser();
                const { user: user_1 } = t7;
                const sessionId_1 = user_1 ? undefined : (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$cart$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGuestSessionId"])() || undefined;
                await supabase_1.rpc("remove_from_cart", {
                    p_product_id: productId,
                    p_session_id: sessionId_1
                });
            }
        })["CartProvider[removeItem]"];
        $[6] = t6;
    } else {
        t6 = $[6];
    }
    const removeItem = t6;
    let t7;
    let t8;
    if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = ()=>setIsOpen(true);
        t8 = ()=>setIsOpen(false);
        $[7] = t7;
        $[8] = t8;
    } else {
        t7 = $[7];
        t8 = $[8];
    }
    let t9;
    if ($[9] !== isLoading || $[10] !== isOpen || $[11] !== items) {
        t9 = {
            items,
            addItem,
            removeItem,
            refreshCart,
            isOpen,
            openDrawer: t7,
            closeDrawer: t8,
            isLoading
        };
        $[9] = isLoading;
        $[10] = isOpen;
        $[11] = items;
        $[12] = t9;
    } else {
        t9 = $[12];
    }
    let t10;
    if ($[13] !== children || $[14] !== t9) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(CartContext.Provider, {
            value: t9,
            children: children
        }, void 0, false, {
            fileName: "[project]/src/context/CartContext.tsx",
            lineNumber: 227,
            columnNumber: 11
        }, this);
        $[13] = children;
        $[14] = t9;
        $[15] = t10;
    } else {
        t10 = $[15];
    }
    return t10;
}
_s(CartProvider, "I0n2v4MqMy2pMlw4Ts9ff6FsCvM=");
_c = CartProvider;
async function _CartProviderFetchCartData() {
    const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createClient"])();
    const { data: t0 } = await supabase.auth.getUser();
    const { user } = t0;
    const sessionId = user ? undefined : (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$cart$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGuestSessionId"])() || undefined;
    const { data } = await supabase.rpc("get_cart_details", {
        p_session_id: sessionId
    });
    return data;
}
const useCart = ()=>{
    _s1();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(1);
    if ($[0] !== "b9bb432231fdb4ba4f7a757b3b9be6182013ba3fb23f05f66f416bf106f1d32f") {
        for(let $i = 0; $i < 1; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "b9bb432231fdb4ba4f7a757b3b9be6182013ba3fb23f05f66f416bf106f1d32f";
    }
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(CartContext);
    if (!context) {
        throw new Error("useCart must be used within a CartProvider");
    }
    return context;
};
_s1(useCart, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
__turbopack_context__.k.register(_c, "CartProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_b942abb6._.js.map