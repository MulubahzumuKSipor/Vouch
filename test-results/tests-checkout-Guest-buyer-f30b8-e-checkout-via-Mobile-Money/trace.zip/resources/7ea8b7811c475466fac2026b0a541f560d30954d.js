(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_65e4106a._.js",
  "static/chunks/src_4be5ad86._.js",
  "static/chunks/src_styles_c26a7cf7._.css"
],
    source: "dynamic"
});
